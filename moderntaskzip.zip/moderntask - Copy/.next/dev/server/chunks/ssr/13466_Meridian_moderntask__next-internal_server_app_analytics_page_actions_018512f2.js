module.exports = [
"[project]/OneDrive/Meridian/moderntask/.next-internal/server/app/analytics/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Meridian_moderntask__next-internal_server_app_analytics_page_actions_018512f2.js.map