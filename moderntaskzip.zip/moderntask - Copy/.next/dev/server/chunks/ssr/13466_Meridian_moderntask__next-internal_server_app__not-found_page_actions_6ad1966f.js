module.exports = [
"[project]/OneDrive/Meridian/moderntask/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Meridian_moderntask__next-internal_server_app__not-found_page_actions_6ad1966f.js.map