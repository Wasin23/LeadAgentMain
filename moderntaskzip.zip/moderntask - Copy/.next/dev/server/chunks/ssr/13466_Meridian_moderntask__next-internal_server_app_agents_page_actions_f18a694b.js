module.exports = [
"[project]/OneDrive/Meridian/moderntask/.next-internal/server/app/agents/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Meridian_moderntask__next-internal_server_app_agents_page_actions_f18a694b.js.map