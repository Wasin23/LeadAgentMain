module.exports = [
"[project]/OneDrive/Meridian/moderntask/.next-internal/server/app/operations/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Meridian_moderntask__next-internal_server_app_operations_page_actions_813f7491.js.map