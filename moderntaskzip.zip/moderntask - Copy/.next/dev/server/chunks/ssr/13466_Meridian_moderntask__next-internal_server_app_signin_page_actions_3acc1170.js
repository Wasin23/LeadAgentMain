module.exports = [
"[project]/OneDrive/Meridian/moderntask/.next-internal/server/app/signin/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Meridian_moderntask__next-internal_server_app_signin_page_actions_3acc1170.js.map