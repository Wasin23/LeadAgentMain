module.exports = [
"[project]/OneDrive/Meridian/moderntask/.next-internal/server/app/email-queue/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Meridian_moderntask__next-internal_server_app_email-queue_page_actions_ef2c2f45.js.map